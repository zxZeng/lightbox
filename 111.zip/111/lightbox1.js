/**
 * Created by Administrator on 2017/11/24.
 */
/**
 * Created by Administrator on 2017/11/23 0023.
 */
//{ selector: ".classname" , prev:��img/sdd.png�� �� next:"img/next.png" , texiao:"pull"}
(function () {
    var lightBoxObj = {
        init:function(option){
            option.prev = option.prev || "img/toPre.png";
            option.next = option.next || "img/toNext.png";
            option.teixiao = option.next || "fade";
            var index = 0;
            var str = "";
            var srcArray = [];
            var imgArray = $(option.selector+" figure img");
            for(var i = 0 ; i < imgArray.length ; i++){
                srcArray[i] = imgArray[i].attributes.src.value;
                str +='<img src="'+srcArray[i]+'" alt="" class="bannerImg">';
            }

            var node = '<div id="mask"> ' +
                '<div class="banner"> ' + str +
                '<span class="close"><img src="img/close.png" alt=""></span> ' +
                '<div class="controlBlock"> ' +
                '<span class="toPre"><img src="img/toPre.png" alt=""></span> ' +
                '<span class="toNext"><img src="img/toNext.png" alt=""></span> ' +
                '</div> ' +
                '</div> ' +
                '</div>';

            $(node).insertAfter("#lightBox");
            $("#lightBox .bannerImg").hide();
            $("#mask").css("height",$(window).height()+"px");


            $("#lightBox figure").click(function(){
                $("#lightBox").fadeOut();
                $("#mask").fadeIn();
                index = $(this).index("figure");
                $($("#lightBoxContainer .bannerImg")[index]).fadeIn()
                    .siblings(".bannerImg").fadeOut();
            });

            $("#lightBoxContainer .toPre").click(function(){
                index === 0 ? index = imgArray.length-1:index--;
                $($("#lightBoxContainer .bannerImg")[index]).fadeIn()
                    .siblings(".bannerImg").fadeOut();
            });


            $("#lightBoxContainer .toNext").click(function(){
                index === imgArray.length-1 ? index = 0 : index++;
                $($("#lightBoxContainer .bannerImg")[index]).fadeIn()
                    .siblings("#lightBoxContainer .bannerImg").fadeOut();
            });

            $("#lightBoxContainer .close").click(function(){
                $("#mask").fadeOut();
                $("#lightBox").fadeIn();
            });
        }
    };
    window.lightBox = {init:lightBoxObj.init}
})();

window.onload = lightBox.init();